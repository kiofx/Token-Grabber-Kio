README Token-Grabber-Kio

Only Supported by Windows


STEPS:
1.Open the File Token-Grabber-Kio.py with the Editor
2.Paste the Webhook you created to ´´WEBHOOK HERE``
3.Save the file
4.Send the File to your victims and theyre token will appear in the Webhook Channel

HOW TO CREATE AN WEBHOOK:
1.Go to a Server on Discord (Created by Yourself)
2.Edit a Channel
3.Go to Integrations
4.Click Create Webhook
5.Click Copy Webhook URL
(You can edit the Webhook whenever you want)


Socials:
Twittwer (https://twitter.com/kio_vlt)
Github (https://github.com/kiofx)
Discord (https://discord.gg/NyQjVYtC)


Donate me

PayPal (paypal.me/fredoonfire)